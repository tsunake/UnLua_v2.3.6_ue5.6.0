local Args = table.pack(...)[1]
_G.GWorld = Args.GWorld