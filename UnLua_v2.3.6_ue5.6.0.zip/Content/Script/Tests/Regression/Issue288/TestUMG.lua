local M = UnLua.Class()

function M:Construct()
end

return M
