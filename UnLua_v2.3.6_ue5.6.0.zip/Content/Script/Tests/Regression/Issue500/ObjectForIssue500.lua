local M = UnLua.Class()

function M.Test()
    return "LUA"
end

return M