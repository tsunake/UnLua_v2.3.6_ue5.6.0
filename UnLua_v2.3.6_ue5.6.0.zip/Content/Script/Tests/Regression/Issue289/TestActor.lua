local M = UnLua.Class()

function M:ReceiveBeginPlay()
end

return M
