local M = UnLua.Class()

function M:Test(Dest, Obj, Radius, bStop)
    return Dest, nil, Radius, bStop
end

return M
