local M = UnLua.Class()

function M:GetValue()
    return 1
end

return M
