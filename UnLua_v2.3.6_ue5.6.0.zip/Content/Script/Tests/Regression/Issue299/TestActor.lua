local M = UnLua.Class()

function M:ReceiveBeginPlay()
end

function M:TestForIssue299()
end

return M
