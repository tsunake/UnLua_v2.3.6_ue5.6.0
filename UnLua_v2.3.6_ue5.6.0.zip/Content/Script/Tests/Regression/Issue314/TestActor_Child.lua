local M = Class("Tests.Regression.Issue314.TestActor_Parent")

return M
