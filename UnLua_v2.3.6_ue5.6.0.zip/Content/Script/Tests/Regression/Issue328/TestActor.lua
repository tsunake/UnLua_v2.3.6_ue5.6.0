local M = UnLua.Class()

function M:TestForIssue328()
    return true
end

return M
