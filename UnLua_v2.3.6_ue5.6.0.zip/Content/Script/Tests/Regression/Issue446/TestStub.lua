local M = UnLua.Class()

function M:Test()
    Issue446_Result = true
end

return M
