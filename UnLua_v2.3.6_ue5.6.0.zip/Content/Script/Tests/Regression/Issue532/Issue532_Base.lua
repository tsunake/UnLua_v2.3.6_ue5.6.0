local M = UnLua.Class()

function M:Construct()
    print("Base Construct")
end

return M