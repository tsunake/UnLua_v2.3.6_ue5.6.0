require "UnLua"

---@type Issue532_UMG_C
local M = UnLua.Class("Tests.Regression.Issue532.Issue532_Base")

return M
