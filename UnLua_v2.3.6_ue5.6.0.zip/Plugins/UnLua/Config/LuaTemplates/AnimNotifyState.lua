--
-- DESCRIPTION
--
-- @COMPANY **
-- @AUTHOR **
-- @DATE ${date} ${time}
--

---@type ClassName
local M = UnLua.Class()

-- function M:Received_NotifyBegin(MeshComp, Animation, TotalDuration)
-- end

-- function M:Received_NotifyTick(MeshComp, Animation, FrameDeltaTime)
-- end

-- function M:Received_NotifyEnd(MeshComp, Animation)
-- end

return M