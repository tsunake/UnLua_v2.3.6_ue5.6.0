--
-- DESCRIPTION
--
-- @COMPANY **
-- @AUTHOR **
-- @DATE ${date} ${time}
--

---@type ClassName
local M = UnLua.Class()

-- function M:Initialize(Initializer)
-- end

-- function M:BlueprintInitializeAnimation()
-- end

-- function M:BlueprintBeginPlay()
-- end

-- function M:BlueprintUpdateAnimation(DeltaTimeX)
-- end

-- function M:BlueprintPostEvaluateAnimation()
-- end

return M
