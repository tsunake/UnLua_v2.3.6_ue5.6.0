#pragma once
#ifndef _PS5_SIGNAL
#define _PS5_SIGNAL
#endif

#include <sys/signal.h>
